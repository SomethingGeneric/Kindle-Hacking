send_string '^' 'DEL'

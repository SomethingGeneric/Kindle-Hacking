send_string '?' 'DEL'

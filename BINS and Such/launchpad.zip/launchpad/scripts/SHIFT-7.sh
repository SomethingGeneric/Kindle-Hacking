send_string '&' 'DEL'

send_string '%' 'DEL'
